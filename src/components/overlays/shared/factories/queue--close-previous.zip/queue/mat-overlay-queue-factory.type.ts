import { IGenericMatOverlay } from '../../instance/types/generic-mat-overlay.type';

export interface IMatOverlayQueueFactoryFactory<GOverlay extends IGenericMatOverlay> {
  (): PromiseLike<GOverlay> | GOverlay;
}

export interface IMatOverlayQueueFactoryOptions {
  queueStrategy?: 'await-previous-closed' | 'force-previous-close';
  awaitOpened?: boolean;
  signal?: AbortSignal;
}

export interface IMatOverlayQueueFactory {
  <GOverlay extends IGenericMatOverlay>(
    factory: IMatOverlayQueueFactoryFactory<GOverlay>,
    options?: IMatOverlayQueueFactoryOptions,
  ): Promise<GOverlay>;
}
