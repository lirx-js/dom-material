import { IMatOverlayQueueFactory, IMatOverlayQueueFactoryFactory, IMatOverlayQueueFactoryOptions } from '../mat-overlay-queue-factory.type';
import { IGenericMatOverlay } from '../../../instance/types/generic-mat-overlay.type';
import { noop, createAbortError } from '@lirx/utils';

export function createMatOverlayQueueFactory(): IMatOverlayQueueFactory {
  let queue: Promise<IGenericMatOverlay> | undefined;

  return <GOverlay extends IGenericMatOverlay>(
    factory: IMatOverlayQueueFactoryFactory<GOverlay>,
    {
      queueStrategy = 'force-previous-close',
      awaitOpened = true,
      signal,
    }: IMatOverlayQueueFactoryOptions = {},
  ): Promise<GOverlay> => {
    const currentQueue: Promise<any> = (queue === void 0)
      ? Promise.resolve()
      : queue
        .then((overlay: IGenericMatOverlay): Promise<any> => {
          switch (queueStrategy) {
            case 'await-previous-closed':
              return overlay.untilState('closed');
            case 'force-previous-close':
              return overlay.close();
          }
        }, noop);

    const newQueue: Promise<GOverlay> = currentQueue
      .then(factory);

    queue = newQueue;

    if (awaitOpened) {
      return newQueue
        .then((instance: GOverlay): Promise<GOverlay> => {
          return instance.untilState('opened', { signal })
            .then(
              (): GOverlay => instance,
              (): never => {
                throw new Error(`Overlay closed before it finished to open.`);
              },
            );
        });
    } else {
      return newQueue
        .then((instance: GOverlay): Promise<GOverlay> | GOverlay => {
          if (signal?.aborted) {
            throw createAbortError({ signal });
          } else {
            return instance;
          }
        });
    }
  };
}
