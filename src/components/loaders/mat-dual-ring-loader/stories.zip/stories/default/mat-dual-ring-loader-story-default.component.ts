import { compileReactiveHTMLAsComponentTemplate, Component } from '@lirx/dom';
import { AppStoryPreviewComponent } from '../../../../../../doc/src/components/app-story-preview/app-story-preview.component';
import { AppStoryComponent } from '../../../../../../doc/src/components/app-story/app-story.component';
import { MatDualRingLoaderComponent } from '../../mat-dual-ring-loader.component';

// @ts-ignore
import html from './mat-dual-ring-loader-story-default.component.html?raw';

export const MatDualRingLoaderStoryDefaultComponent = new Component<HTMLElement, object, object>({
  name: 'mat-dual-ring-loader-story-default',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    components: [AppStoryComponent, MatDualRingLoaderComponent, AppStoryPreviewComponent],
  }),
});
