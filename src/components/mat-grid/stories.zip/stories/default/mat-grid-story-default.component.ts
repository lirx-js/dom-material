import {
  compileReactiveHTMLAsComponentTemplate,
  Component,
  Input,
  input,
  VirtualComponentNode,
} from '@lirx/dom';
import { AppStoryPreviewComponent } from '../../../../../doc/src/components/app-story-preview/app-story-preview.component';
import { AppStoryComponent } from '../../../../../doc/src/components/app-story/app-story.component';
import { MatGridItemComponent } from '../../fragments/mat-grid-item/mat-grid-item.component';
import { MatGridComponent } from '../../mat-grid.component';

// @ts-ignore
import html from './mat-grid-story-default.component.html?raw';

export interface IMatLoadingComponentData {
  readonly loading: Input<boolean>;
}

export const MatGridStoryDefaultComponent = new Component<
  HTMLElement,
  IMatLoadingComponentData,
  object
>({
  name: 'mat-loading-story-default',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    components: [
      AppStoryComponent,
      AppStoryPreviewComponent,
      MatGridComponent,
      MatGridItemComponent,
    ],
  }),
  componentData: (): IMatLoadingComponentData => {
    return {
      loading: input<boolean>(false),
    };
  },
  templateData: (node: VirtualComponentNode<HTMLElement, IMatLoadingComponentData>): void => {
    const loading$ = node.input$('loading');

    node.setReactiveClass('mat--loading', loading$);
  },
});
