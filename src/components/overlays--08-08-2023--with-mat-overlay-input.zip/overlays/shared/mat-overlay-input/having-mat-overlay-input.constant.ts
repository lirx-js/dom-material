import { IGenericHavingMatOverlayInput } from './having-mat-overlay-input.type';
import { MAT_OVERLAY_INPUT } from './mat-overlay-input.constant';
import { MAT_OVERLAY_INPUT_NAME } from './mat-overlay-input-name.constant';

export const HAVING_MAT_OVERLAY_INPUT: IGenericHavingMatOverlayInput = {
  [MAT_OVERLAY_INPUT_NAME]: MAT_OVERLAY_INPUT,
};


