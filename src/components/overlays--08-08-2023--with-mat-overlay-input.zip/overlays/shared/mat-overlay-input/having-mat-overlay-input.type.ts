import { IMatOverlayInputName } from './mat-overlay-input-name.type';
import { IMatOverlayInput } from './mat-overlay-input.type';

export type IHavingMatOverlayInput<GElement extends Element, GData extends object> = Record<IMatOverlayInputName, IMatOverlayInput<GElement, GData>>;

export type IGenericHavingMatOverlayInput = IHavingMatOverlayInput<any, any>;


