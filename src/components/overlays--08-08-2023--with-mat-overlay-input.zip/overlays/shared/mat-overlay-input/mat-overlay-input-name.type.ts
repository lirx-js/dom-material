import { MAT_OVERLAY_INPUT_NAME } from './mat-overlay-input-name.constant';

export type IMatOverlayInputName = typeof MAT_OVERLAY_INPUT_NAME;
