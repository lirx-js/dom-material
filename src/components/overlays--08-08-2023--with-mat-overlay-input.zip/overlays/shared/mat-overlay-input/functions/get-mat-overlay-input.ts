import { IObservable } from '@lirx/core';
import { VirtualComponentNode } from '@lirx/dom';
import { MAT_OVERLAY_INPUT_NAME } from '../mat-overlay-input-name.constant';
import { IHavingMatOverlayInput } from '../having-mat-overlay-input.type';
import { IVirtualComponentMatOverlayInput } from '../../instance/types/for-component/virtual-component-mat-overlay.type';

export function getMatOverlayInput$$<GElement extends Element, GData extends object>(
  node: VirtualComponentNode<any, IHavingMatOverlayInput<GElement, GData>>,
): IObservable<IVirtualComponentMatOverlayInput<GElement, GData>> {
  return node.data[MAT_OVERLAY_INPUT_NAME].subscribe;
}
