import { IObservable, IObserver, map$$ } from '@lirx/core';
import { IGenericVirtualComponentNode } from '@lirx/dom';
import { IGenericMatOverlay } from '../../instance/types/generic-mat-overlay.type';
import { getMatOverlayInput$$ } from './get-mat-overlay-input';

export interface ICreateMatOverlayCloseObserverFilterFunction<GObserverValue> {
  (
    value: GObserverValue,
  ): boolean;
}

export function createMatOverlayCloseObserver<GObserverValue>(
  node: IGenericVirtualComponentNode,
  filter: ICreateMatOverlayCloseObserverFilterFunction<GObserverValue> = () => true,
): IObservable<IObserver<GObserverValue>> {
  return map$$(getMatOverlayInput$$(node), (instance: IGenericMatOverlay): IObserver<GObserverValue> => {
    return (
      value: GObserverValue,
    ): void => {
      if (filter(value)) {
        instance.close();
      }
    };
  });
}

