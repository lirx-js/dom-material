import { IInput } from '@lirx/dom';
import { IVirtualComponentMatOverlayInput } from '../instance/types/for-component/virtual-component-mat-overlay.type';

export type IMatOverlayInput<GElement extends Element, GData extends object> = IInput<IVirtualComponentMatOverlayInput<GElement, GData>>;

export type IGenericMatOverlayInput = IMatOverlayInput<any, any>;
