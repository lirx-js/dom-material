import { IGenericMatOverlayInput } from './mat-overlay-input.type';
import { input } from '@lirx/dom';
import { IGenericVirtualComponentMatOverlayInput } from '../instance/types/for-component/virtual-component-mat-overlay.type';

export const MAT_OVERLAY_INPUT: IGenericMatOverlayInput = input<IGenericVirtualComponentMatOverlayInput>();
