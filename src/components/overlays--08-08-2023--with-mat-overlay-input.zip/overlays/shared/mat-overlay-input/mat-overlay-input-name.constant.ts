export const MAT_OVERLAY_INPUT_NAME = Symbol('matOverlay');

