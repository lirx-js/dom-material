export interface IMatSnackbarOnClickAction {
  (
    event: MouseEvent,
  ): void;
}
