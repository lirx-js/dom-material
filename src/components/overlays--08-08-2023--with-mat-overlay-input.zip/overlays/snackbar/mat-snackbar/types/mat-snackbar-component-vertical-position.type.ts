export type IMatSnackbarComponentVerticalPosition =
  | 'top'
  | 'bottom'
  ;
