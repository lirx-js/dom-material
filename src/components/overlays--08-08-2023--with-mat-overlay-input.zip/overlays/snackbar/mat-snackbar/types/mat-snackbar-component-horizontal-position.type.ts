export type IMatSnackbarComponentHorizontalPosition =
  | 'left'
  | 'center'
  | 'right'
  ;
