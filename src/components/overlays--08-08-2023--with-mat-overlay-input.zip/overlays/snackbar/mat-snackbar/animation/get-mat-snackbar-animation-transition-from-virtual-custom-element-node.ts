import { VirtualComponentNode } from '@lirx/dom';
import { IVoidTransitionFunction } from '@lirx/animations';
import {
  getVirtualComponentNodeInputAfterMicroDelay,
} from '../../../../../functions/get-virtual-custom-element-node-input-after-micro-delay';
import { IMatSnackbarComponentHorizontalPosition } from '../types/mat-snackbar-component-horizontal-position.type';
import { IMatSnackbarComponentVerticalPosition } from '../types/mat-snackbar-component-vertical-position.type';
import { getMatSnackbarAnimationTransition } from './get-mat-snackbar-animation-transition';
import { IObservableLike } from '@lirx/core';

export function getMatSnackbarAnimationTransitionFromVirtualComponentNode(
  node: VirtualComponentNode<any, { horizontalPosition: IObservableLike<IMatSnackbarComponentHorizontalPosition>; verticalPosition: IObservableLike<IMatSnackbarComponentVerticalPosition>; }>,
  signal: AbortSignal,
): Promise<IVoidTransitionFunction> {
  return Promise.all([
    getVirtualComponentNodeInputAfterMicroDelay(node, 'horizontalPosition', { signal }),
    getVirtualComponentNodeInputAfterMicroDelay(node, 'verticalPosition', { signal }),
  ])
    .then((
      [
        horizontalPosition,
        verticalPosition,
      ]:
        [
          IMatSnackbarComponentHorizontalPosition,
          IMatSnackbarComponentVerticalPosition,
        ],
    ): IVoidTransitionFunction => {
      return getMatSnackbarAnimationTransition({
        element: node.elementNode as HTMLElement,
        horizontalPosition,
        verticalPosition,
      });
    });
}
