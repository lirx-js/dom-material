import { IVirtualComponentNodeConfig, VirtualComponentNode } from '@lirx/dom';
import {
  IMatOverlayOpenCloseOptions,
  createMatOverlayOpenCloseOptionsFromReversibleTransitionFactory,
} from '../../../shared/instance/animation/create-mat-overlay-open-close-options-from-reversible-transition-factory';
import {
  getMatSnackbarAnimationTransitionFromVirtualComponentNode,
} from './get-mat-snackbar-animation-transition-from-virtual-custom-element-node';

export interface ICreateMatOverlayOpenCloseOptionsForMatSnackbarOptions {
  animationDuration?: number;
}

export function createMatOverlayOpenCloseOptionsForMatSnackbar<GConfig extends IVirtualComponentNodeConfig>(
  {
    animationDuration = 150,
  }: ICreateMatOverlayOpenCloseOptionsForMatSnackbarOptions = {},
): IMatOverlayOpenCloseOptions<VirtualComponentNode<GConfig>> {
  return createMatOverlayOpenCloseOptionsFromReversibleTransitionFactory<VirtualComponentNode<GConfig>>({
    transitionFactory: getMatSnackbarAnimationTransitionFromVirtualComponentNode,
    duration: animationDuration,
  });
}

