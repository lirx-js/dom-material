import { compileStyleAsComponentStyle, createComponent, INJECT_CONTENT_TEMPLATE, VirtualCustomElementNode } from '@lirx/dom';
import { FocusController } from './classes/focus-controller/focus-controller.class';
import { FocusStack } from './classes/focus-stack/focus-stack.class';
import { debounceMicrotask$$ } from '@lirx/core';

// @ts-ignore
import style from './mat-focus-trap.component.scss?inline';

/**
 * COMPONENT: 'mat-focus-trap'
 */

export interface IMatFocusTrapComponentConfig {
  element: HTMLElement;
}

export const MatFocusTrapComponent = createComponent<IMatFocusTrapComponentConfig>({
  name: 'mat-focus-trap',
  template: INJECT_CONTENT_TEMPLATE,
  styles: [compileStyleAsComponentStyle(style)],
  init: (node: VirtualCustomElementNode<IMatFocusTrapComponentConfig>): void => {

    const focusStack = FocusStack.controller(
      new FocusController({
        container: node.elementNode,
        next: FocusController.NEXT_LOOP,
      }),
    );

    const isDOMConnected$ = debounceMicrotask$$(node.isConnected$);

    isDOMConnected$((connected: boolean): void => {
      if (connected) {
        focusStack.activate();
      } else {
        focusStack.remove();
      }
    });
  },
});
