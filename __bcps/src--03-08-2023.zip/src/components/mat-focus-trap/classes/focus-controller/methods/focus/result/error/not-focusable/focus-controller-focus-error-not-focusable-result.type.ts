import {
  IFocusControllerFocusErrorResult,
} from '../focus-controller-focus-error-result.type';

export type IFocusControllerFocusErrorNotFocusableResult = IFocusControllerFocusErrorResult<'not-focusable'>;
