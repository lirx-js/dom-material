export interface IFocusControllerFocusErrorResult<GType extends string> {
  success: false;
  type: GType;
}
