import { IFocusControllerFocusSuccessResult } from './focus-controller-focus-success-result.type';

export const FOCUS_CONTROLLER_FOCUS_SUCCESS_RESULT: IFocusControllerFocusSuccessResult = {
  success: true,
};
