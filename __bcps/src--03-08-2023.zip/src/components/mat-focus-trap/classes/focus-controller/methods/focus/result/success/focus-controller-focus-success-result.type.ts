export interface IFocusControllerFocusSuccessResult {
  success: true;
}
