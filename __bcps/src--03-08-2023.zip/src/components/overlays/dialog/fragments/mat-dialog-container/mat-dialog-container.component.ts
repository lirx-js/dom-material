import {
  fromEventTarget,
  fromSelfEventTarget,
  IMapFilterMapFunctionReturn,
  map$$,
  MAP_FILTER_DISCARD,
  mapFilter$$,
  merge,
} from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { MatFocusTrapComponent } from '../../../../mat-focus-trap/mat-focus-trap.component';

// @ts-ignore
import html from './mat-dialog-container.component.html?raw';
// @ts-ignore
import style from './mat-dialog-container.component.scss?inline';
import { IUnsubscribe } from '@lirx/utils';

/** TYPES **/

export type IMatDialogContainerComponentCloseType =
  | 'backdrop'
  | 'escape'
  ;

/**
 * COMPONENT: 'mat-dialog-container'
 *
 * This is the main container for a dialog. It includes a backdrop and a "content" area (white middle space)
 */

export interface IMatDialogContainerComponentConfig {
  element: HTMLElement;
  outputs:
    | ['close', IMatDialogContainerComponentCloseType];
}

export type IMatDialogContainerVirtualCustomElementNode = VirtualCustomElementNode<IMatDialogContainerComponentConfig>;

export const MatDialogContainerComponent = createComponent<IMatDialogContainerComponentConfig>({
  name: 'mat-dialog-container',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatFocusTrapComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  outputs: [
    'close',
  ],
  init: (node: IMatDialogContainerVirtualCustomElementNode): void => {
    /* CLOSE */

    const $close = node.outputs.$set('close');

    const backdropClose$ = map$$(
      fromSelfEventTarget<'click', MouseEvent>(node.elementNode, 'click'),
      (): IMatDialogContainerComponentCloseType => 'backdrop',
    );

    const escapeClose$ = mapFilter$$(
      fromEventTarget<'keydown', KeyboardEvent>(node.elementNode, 'keydown'),
      (event: KeyboardEvent): IMapFilterMapFunctionReturn<IMatDialogContainerComponentCloseType> => {
        return (event.key === 'Escape')
          ? 'escape'
          : MAP_FILTER_DISCARD;
      },
    );

    const close$ = merge([
      backdropClose$,
      escapeClose$,
    ]);

    node.onConnected((): IUnsubscribe => {
      return close$($close);
    });
  },
});
