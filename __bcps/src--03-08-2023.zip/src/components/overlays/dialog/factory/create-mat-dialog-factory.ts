import { IVoidTransitionFunction } from '@lirx/animations';
import { IComponent, IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { getMatDialogAnimationTransition } from '../animation/get-mat-dialog-animation-transition';
import {
  createMatOverlayFactoryFromComponent,
  IMatOverlayFactoryFromComponent,
} from '../../shared/factories/sync/create/create-mat-overlay-factory-from-component';
import {
  createMatOverlayOpenCloseOptionsFromReversibleTransitionFactory,
} from '../../shared/instance/animation/create-mat-overlay-open-close-options-from-reversible-transition-factory';

export interface IMatDialogFactoryOptions {
  animationDuration?: number;
}

export type IMatDialogFactory<GConfig extends IVirtualCustomElementNodeConfig> = IMatOverlayFactoryFromComponent<GConfig>;

export function createMatDialogFactory<GConfig extends IVirtualCustomElementNodeConfig>(
  component: IComponent<GConfig>,
  {
    animationDuration = 150,
  }: IMatDialogFactoryOptions = {},
): IMatDialogFactory<GConfig> {
  return createMatOverlayFactoryFromComponent(
    component,
    createMatOverlayOpenCloseOptionsFromReversibleTransitionFactory({
      transitionFactory: (
        node: VirtualCustomElementNode<GConfig>,
      ): IVoidTransitionFunction => {
        return getMatDialogAnimationTransition({
          element: node.elementNode as HTMLElement,
        });
      },
      duration: animationDuration,
    }),
  );
}

