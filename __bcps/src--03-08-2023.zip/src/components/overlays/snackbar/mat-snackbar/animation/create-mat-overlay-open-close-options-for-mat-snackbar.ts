import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import {
  IMatOverlayOpenCloseOptions,
  createMatOverlayOpenCloseOptionsFromReversibleTransitionFactory,
} from '../../../shared/instance/animation/create-mat-overlay-open-close-options-from-reversible-transition-factory';
import { IVoidTransitionFunction } from '@lirx/animations';
import {
  getVirtualCustomElementNodeInputAfterMicroDelay,
} from '../../../../../functions/get-virtual-custom-element-node-input-after-micro-delay';
import { getMatSnackbarAnimationTransition } from './get-mat-snackbar-animation-transition';

export interface ICreateMatOverlayOpenCloseOptionsForMatSnackbarOptions {
  animationDuration?: number;
}

export function createMatOverlayOpenCloseOptionsForMatSnackbar<GConfig extends IVirtualCustomElementNodeConfig>(
  {
    animationDuration = 150,
  }: ICreateMatOverlayOpenCloseOptionsForMatSnackbarOptions = {},
): IMatOverlayOpenCloseOptions<VirtualCustomElementNode<GConfig>> {
  return createMatOverlayOpenCloseOptionsFromReversibleTransitionFactory<VirtualCustomElementNode<GConfig>>({
    transitionFactory: (
      node: VirtualCustomElementNode<GConfig>,
      signal: AbortSignal,
    ): Promise<IVoidTransitionFunction> => {
      return Promise.all([
        getVirtualCustomElementNodeInputAfterMicroDelay(node, 'horizontalPosition', { signal }),
        getVirtualCustomElementNodeInputAfterMicroDelay(node, 'verticalPosition', { signal }),
      ])
        .then(([horizontalPosition, verticalPosition]) => {
          return getMatSnackbarAnimationTransition({
            element: node.elementNode as HTMLElement,
            horizontalPosition,
            verticalPosition,
          });
        });
    },
    duration: animationDuration,
  });
}
