import { IVirtualCustomElementNodeSlotsMap } from '@lirx/dom';

export interface IMatOverlayFactoryOpenOptions {
  slots?: IVirtualCustomElementNodeSlotsMap;
}

