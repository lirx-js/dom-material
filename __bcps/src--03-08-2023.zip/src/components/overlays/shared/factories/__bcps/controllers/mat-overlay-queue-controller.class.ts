import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { MatOverlay } from '../../../instance/mat-overlay.class';
import { IMatOverlayFactoryOpenOptions } from '../types/mat-overlay-factory-open-options.type';
import { IMatOverlayQueueOpenOptions, MatOverlayQueue } from './mat-overlay-queue.class';
import { MatOverlayController } from './mat-overlay-controller.class';

/** TYPES **/

/* OPEN */

export interface IMatOverlayQueueControllerOpenOptions extends IMatOverlayQueueOpenOptions, IMatOverlayFactoryOpenOptions {

}

/** CLASS **/

export class MatOverlayQueueController<GConfig extends IVirtualCustomElementNodeConfig, GData> {
  readonly #controller: MatOverlayController<GConfig, GData>;
  readonly #queue: MatOverlayQueue;

  constructor(
    controller: MatOverlayController<GConfig, GData>,
    queue: MatOverlayQueue = new MatOverlayQueue(),
  ) {
    this.#controller = controller;
    this.#queue = queue;
  }

  open(
    data: GData,
    options?: IMatOverlayQueueControllerOpenOptions,
  ): Promise<MatOverlay<VirtualCustomElementNode<GConfig>>> {
    return this.#queue.open(
      (): MatOverlay<VirtualCustomElementNode<GConfig>> => {
        return this.#controller.open(data, options);
      },
      options,
    );
  }
}
