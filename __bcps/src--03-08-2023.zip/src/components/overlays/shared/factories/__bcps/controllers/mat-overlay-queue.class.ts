import { IGenericMatOverlay } from '../../../instance/types/generic-mat-overlay.type';
import { noop, createAbortError } from '@lirx/utils';

/** TYPES **/

/* FACTORY */

export interface IMatOverlayQueueFactory<GOverlay extends IGenericMatOverlay> {
  (): PromiseLike<GOverlay> | GOverlay;
}

/* OPEN */

export interface IMatOverlayQueueOpenOptions {
  queueStrategy?: 'await-previous-closed' | 'force-previous-close';
  awaitOpened?: boolean;
  signal?: AbortSignal;
}

/** CLASS **/

export class MatOverlayQueue {
  #queue: Promise<IGenericMatOverlay> | undefined;

  open<GOverlay extends IGenericMatOverlay>(
    factory: IMatOverlayQueueFactory<GOverlay>,
    {
      queueStrategy = 'force-previous-close',
      awaitOpened = true,
      signal,
    }: IMatOverlayQueueOpenOptions = {},
  ): Promise<GOverlay> {
    const currentQueue: Promise<any> = (this.#queue === void 0)
      ? Promise.resolve()
      : this.#queue
        .then((overlay: IGenericMatOverlay): Promise<any> => {
          switch (queueStrategy) {
            case 'await-previous-closed':
              return overlay.untilState('closed');
            case 'force-previous-close':
              return overlay.close();
          }
        }, noop);

    const newQueue: Promise<GOverlay> = currentQueue
      .then(factory);

    this.#queue = newQueue;

    if (awaitOpened) {
      return newQueue
        .then((instance: GOverlay): Promise<GOverlay> => {
          return instance.untilState('opened', { signal })
            .then((): GOverlay => instance);
        });
    } else {
      return newQueue
        .then((instance: GOverlay): Promise<GOverlay> | GOverlay => {
          if (signal?.aborted) {
            throw createAbortError({ signal });
          } else {
            return instance;
          }
        });
    }
  }
}

