import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { IMatOverlayOptions } from '../../../instance/types/mat-overlay-options.type';

export interface IMatOverlayFactoryOptions<GConfig extends IVirtualCustomElementNodeConfig> extends Omit<IMatOverlayOptions<VirtualCustomElementNode<GConfig>>, 'node'> {
}
