import { IComponent, IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { MatOverlay } from '../../instance/mat-overlay.class';
import { MAT_OVERLAY_INPUT_NAME } from '../../mat-overlay-input/mat-overlay-input-name.constant';
import { IMatOverlayFactoryOpenOptions } from './types/mat-overlay-factory-open-options.type';
import { IMatOverlayFactoryOptions } from './types/mat-overlay-factory-options.type';
import { createMatOverlayFactoryFunction } from './create-mat-overlay-factory-function';
import { IMatOverlayFactory } from '../mat-overlay-factory.type';

/**
 * This class is used to generate an overlay from a component.
 */
export class MatOverlayFactory<GConfig extends IVirtualCustomElementNodeConfig> {
  readonly #component: IComponent<GConfig>;
  readonly #open: IMatOverlayFactory<GConfig>;

  constructor(
    component: IComponent<GConfig>,
    options?: IMatOverlayFactoryOptions<GConfig>,
  ) {
    this.#component = component;
    this.#open = createMatOverlayFactoryFunction<GConfig>(
      component,
      options,
    );
  }

  get component(): IComponent<GConfig> {
    return this.#component;
  }

  /**
   * Creates the "overlay" from the component.
   * It returns a MatOverlay, which animates the overlay, and provides a method to close it.
   */
  open(
    {
      slots,
    }: IMatOverlayFactoryOpenOptions = {},
  ): MatOverlay<VirtualCustomElementNode<GConfig>> {
    const instance = new MatOverlay<VirtualCustomElementNode<GConfig>>({
      ...this.#options,
      node: this.#component.create(slots),
    });

    if (instance.node.inputs.has(MAT_OVERLAY_INPUT_NAME)) {
      instance.node.inputs.set(MAT_OVERLAY_INPUT_NAME, instance as any);
    }

    return instance;
  }
}




