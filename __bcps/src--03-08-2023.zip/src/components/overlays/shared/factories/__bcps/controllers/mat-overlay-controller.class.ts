import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode, IComponent } from '@lirx/dom';
import { MatOverlay } from '../../../instance/mat-overlay.class';
import { IMatOverlayFactoryOpenOptions } from '../types/mat-overlay-factory-open-options.type';
import { MatSnackbarFactory, IMatSnackbarFactoryOptions } from '../../../../snackbar/factory/mat-snackbar-factory.class';

/** TYPES **/



/** CLASS **/

export class MatOverlayController<GConfig extends IVirtualCustomElementNodeConfig, GData> {

  static fromComponent<GConfig extends IVirtualCustomElementNodeConfig, GData>(
    component: IComponent<GConfig>,
    bind: IMatOverlayControllerBindInstanceWithDataFunction<GConfig, GData>,
    options?: IMatSnackbarFactoryOptions,
  ): MatOverlayController<GConfig, GData> {
    return new MatOverlayController<GConfig, GData>(
      new MatSnackbarFactory<GConfig>(
        component,
        options,
      ),
      bind,
    );
  }

  readonly #factory: MatSnackbarFactory<GConfig>;
  readonly #bind: IMatOverlayControllerBindInstanceWithDataFunction<GConfig, GData>;

  constructor(
    factory: MatSnackbarFactory<GConfig>,
    bind: IMatOverlayControllerBindInstanceWithDataFunction<GConfig, GData>,
  ) {
    this.#factory = factory;
    this.#bind = bind;
  }

  open(
    data: GData,
    options?: IMatOverlayFactoryOpenOptions,
  ): MatOverlay<VirtualCustomElementNode<GConfig>> {
    const instance: MatOverlay<VirtualCustomElementNode<GConfig>> = this.#factory.open(options);
    this.#bind(instance, data);
    return instance;
  }
}


/*----*/


export interface IMatOverlayControllerBindInstanceWithDataFunction<GConfig extends IVirtualCustomElementNodeConfig, GData> {
  (
    instance: MatOverlay<VirtualCustomElementNode<GConfig>>,
    data: GData,
  ): void;
}

export interface IMatOverlayController<GConfig extends IVirtualCustomElementNodeConfig, GData> {
  (
    data: GData,
    options?: IMatOverlayFactoryOpenOptions,
  ): MatOverlay<VirtualCustomElementNode<GConfig>>;
}


export function createMatOverlayController<GConfig extends IVirtualCustomElementNodeConfig, GData>(
  factory: MatSnackbarFactory<GConfig>,
  bind: IMatOverlayControllerBindInstanceWithDataFunction<GConfig, GData>,
): IMatOverlayController<GConfig, GData> {
  return (
    data: GData,
    options?: IMatOverlayFactoryOpenOptions,
  ): MatOverlay<VirtualCustomElementNode<GConfig>> => {
    const instance: MatOverlay<VirtualCustomElementNode<GConfig>> = factory.open(options);
    bind(instance, data);
    return instance;
  };
}

