import { IVirtualCustomElementNodeConfig, IComponent, VirtualCustomElementNode } from '@lirx/dom';
import { IMatOverlayFactoryOpenOptions } from './types/mat-overlay-factory-open-options.type';
import { MatOverlay } from '../../instance/mat-overlay.class';
import { MAT_OVERLAY_INPUT_NAME } from '../../mat-overlay-input/mat-overlay-input-name.constant';

import { IMatOverlayFactory } from '../mat-overlay-factory.type';

export function createMatOverlayFactoryFunction<GConfig extends IVirtualCustomElementNodeConfig>(
  component: IComponent<GConfig>,
  {
    slots,
  }: IMatOverlayFactoryOpenOptions = {},
): IMatOverlayFactory<GConfig> {
  return (
    options?: IMatOverlayFactoryOpenOptions,
  ): MatOverlay<VirtualCustomElementNode<GConfig>> => {
    const instance = new MatOverlay<VirtualCustomElementNode<GConfig>>({
      ...options,
      node: component.create(slots),
    });

    if (instance.node.inputs.has(MAT_OVERLAY_INPUT_NAME)) {
      instance.node.inputs.set(MAT_OVERLAY_INPUT_NAME, instance as any);
    }

    return instance;
  };
}
