import { IVirtualCustomElementNodeConfig, IComponent, VirtualCustomElementNode, IVirtualCustomElementNodeSlotsMap } from '@lirx/dom';
import { MatOverlay } from '../../../instance/mat-overlay.class';
import { MAT_OVERLAY_INPUT_NAME } from '../../../mat-overlay-input/mat-overlay-input-name.constant';
import { IMatOverlayFactory } from '../mat-overlay-factory.type';
import { IMatOverlayOptions } from '../../../instance/types/mat-overlay-options.type';

/** TYPES **/

export interface ICreateMatOverlayFactoryFromComponentOptions<GConfig extends IVirtualCustomElementNodeConfig> extends Omit<IMatOverlayOptions<VirtualCustomElementNode<GConfig>>, 'node'> {
}

export interface IMatOverlayFactoryFromComponentOptions {
  slots?: IVirtualCustomElementNodeSlotsMap;
}

export type IMatOverlayFactoryFromComponentArguments = readonly [IMatOverlayFactoryFromComponentOptions];
export type IMatOverlayFactoryFromComponentOverlay<GConfig extends IVirtualCustomElementNodeConfig> = MatOverlay<VirtualCustomElementNode<GConfig>>;

export type IMatOverlayFactoryFromComponent<GConfig extends IVirtualCustomElementNodeConfig> = IMatOverlayFactory<IMatOverlayFactoryFromComponentArguments, IMatOverlayFactoryFromComponentOverlay<GConfig>>;

/** FUNCTION **/

export function createMatOverlayFactoryFromComponent<GConfig extends IVirtualCustomElementNodeConfig>(
  component: IComponent<GConfig>,
  options?: ICreateMatOverlayFactoryFromComponentOptions<GConfig>,
): IMatOverlayFactoryFromComponent<GConfig> {
  return (
    {
      slots,
    }: IMatOverlayFactoryFromComponentOptions = {},
  ): IMatOverlayFactoryFromComponentOverlay<GConfig> => {
    const instance = new MatOverlay<VirtualCustomElementNode<GConfig>>({
      ...options,
      node: component.create(slots),
    });

    if (instance.node.inputs.has(MAT_OVERLAY_INPUT_NAME)) {
      instance.node.inputs.set(MAT_OVERLAY_INPUT_NAME, instance as any);
    }

    return instance;
  };
}
