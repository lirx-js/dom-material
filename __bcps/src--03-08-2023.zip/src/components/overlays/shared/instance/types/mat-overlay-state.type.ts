export type IMatOverlayState =
  | 'opening'
  | 'opened'
  | 'closing'
  | 'closed'
  ;
