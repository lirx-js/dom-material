import { IGenericMatOverlay } from '../instance/types/generic-mat-overlay.type';
import { MAT_OVERLAY_INPUT_NAME } from './mat-overlay-input-name.constant';
import { IMatOverlayInputName } from './mat-overlay-input-name.type';
import {
  IVirtualCustomElementNodeInputMapInputEntry,
} from '@lirx/dom/src/dom-manipulation/virtual-nodes/virtual-custom-element-node/members/inputs/virtual-custom-element-node-input-map.class';

export const MAT_OVERLAY_INPUT: IVirtualCustomElementNodeInputMapInputEntry<IMatOverlayInputName, IGenericMatOverlay> = [MAT_OVERLAY_INPUT_NAME];
