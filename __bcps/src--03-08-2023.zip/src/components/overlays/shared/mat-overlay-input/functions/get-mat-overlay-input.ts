import { IObservable } from '@lirx/core';
import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { MatOverlay } from '../../instance/mat-overlay.class';
import { MAT_OVERLAY_INPUT_NAME } from '../mat-overlay-input-name.constant';

export function getMatOverlayInput$$<GConfig extends IVirtualCustomElementNodeConfig>(
  node: VirtualCustomElementNode<GConfig>,
): IObservable<MatOverlay<VirtualCustomElementNode<GConfig>>> {
  return node.inputs.get$(MAT_OVERLAY_INPUT_NAME);
}
