import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { MatOverlay } from '../instance/mat-overlay.class';
import { IMatOverlayInputName } from './mat-overlay-input-name.type';

export type IMatOverlayInput<GConfig extends IVirtualCustomElementNodeConfig> = [
  IMatOverlayInputName,
  MatOverlay<VirtualCustomElementNode<GConfig>>,
];

