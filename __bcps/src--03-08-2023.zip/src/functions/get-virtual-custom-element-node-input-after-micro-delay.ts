import {
  IVirtualCustomElementNodeConfig,
  InferVirtualCustomElementNodeConfigInputKeys,
  VirtualCustomElementNode,
  InferVirtualCustomElementNodeConfigInputValueFromKey,
} from '@lirx/dom';
import { IObservableToPromiseOptions } from '@lirx/core/src/observable/built-in/to/without-notifications/promise/to-promise';
import { toPromise, debounceMicrotask$$ } from '@lirx/core';

export function getVirtualCustomElementNodeInputAfterMicroDelay<GConfig extends IVirtualCustomElementNodeConfig, GKey extends InferVirtualCustomElementNodeConfigInputKeys<GConfig>>(
  node: VirtualCustomElementNode<GConfig>,
  key: GKey,
  options?: IObservableToPromiseOptions,
): Promise<InferVirtualCustomElementNodeConfigInputValueFromKey<GConfig, GKey>> {
  return toPromise<InferVirtualCustomElementNodeConfigInputValueFromKey<GConfig, GKey>>(
    debounceMicrotask$$(
      node.inputs.get$<GKey>(key),
    ),
    options,
  );
}
