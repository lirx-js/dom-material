import {
  createFocusControllerFocusErrorResult,
} from '../create-focus-controller-focus-error-result';
import { IFocusControllerFocusErrorPreventedResult } from './focus-controller-focus-error-prevented-result.type';

export const FOCUS_CONTROLLER_FOCUS_ERROR_PREVENTED_RESULT: IFocusControllerFocusErrorPreventedResult = createFocusControllerFocusErrorResult('prevented');
