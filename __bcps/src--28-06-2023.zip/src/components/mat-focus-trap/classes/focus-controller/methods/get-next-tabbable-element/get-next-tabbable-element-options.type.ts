export interface IGetNextTabbableElementOptions {
  element?: HTMLElement | null;
  loop?: boolean;
  backward?: boolean;
}
