import { noop } from '@lirx/utils';
import { FocusController } from '../focus-controller/focus-controller.class';

interface IFocusStackOnActivateFunction {
  (): void;
}

interface IFocusStackOnDeactivateFunction {
  (): void;
}

export class FocusStack {
  static #stack: readonly FocusStack[] = [];

  static controller(
    controller: FocusController,
  ): FocusStack {
    return new FocusStack(
      (): void => {
        controller.start();
      },
      (): void => {
        controller.stop();
      },
    );
  }

  readonly #onActivate: IFocusStackOnActivateFunction;
  readonly #onDeactivate: IFocusStackOnDeactivateFunction;

  constructor(
    onActivate: IFocusStackOnActivateFunction,
    onDeactivate: IFocusStackOnDeactivateFunction = noop,
  ) {
    this.#onActivate = onActivate;
    this.#onDeactivate = onDeactivate;
  }

  get active(): boolean {
    return (FocusStack.#stack.length > 0)
      && (FocusStack.#stack[FocusStack.#stack.length - 1] === this);
  }

  activate(): boolean {
    if (this.active) { // already activated
      return false;
    } else {
      const index: number = FocusStack.#stack.indexOf(this);

      if (index === -1) { // new in the stack
        FocusStack.#stack = [
          ...FocusStack.#stack,
          this,
        ];
      } else { // change position in the stack
        FocusStack.#stack = [
          ...FocusStack.#stack.slice(0, index),
          ...FocusStack.#stack.slice(index + 1),
          this,
        ];
      }

      if (FocusStack.#stack.length > 1) { // we have a previously activated one
        FocusStack.#stack[FocusStack.#stack.length - 2].#onDeactivate();
      }
      this.#onActivate();

      return true;
    }
  }

  remove(): boolean {
    const index: number = FocusStack.#stack.indexOf(this);

    if (index === -1) { // not in the stack
      return false;
    } else {
      if (index === FocusStack.#stack.length - 1) { // it's the active one
        FocusStack.#stack = FocusStack.#stack.slice(0, index);
        this.#onDeactivate();

        if (FocusStack.#stack.length > 0) {
          FocusStack.#stack[FocusStack.#stack.length - 1].#onActivate();
        }
      } else {
        FocusStack.#stack = [
          ...FocusStack.#stack.slice(0, index),
          ...FocusStack.#stack.slice(index + 1),
        ];
      }
      return true;
    }
  }
}
