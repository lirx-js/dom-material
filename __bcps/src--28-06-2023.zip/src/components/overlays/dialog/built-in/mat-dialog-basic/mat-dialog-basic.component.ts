import { IObserver } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import {
  MatDialogBodyComponent,
} from '../../fragments/mat-dialog-container/fragments/mat-dialog-content/fragments/mat-dialog-body/mat-dialog-body.component';
import {
  MatDialogFooterComponent,
} from '../../fragments/mat-dialog-container/fragments/mat-dialog-content/fragments/mat-dialog-footer/mat-dialog-footer.component';
import {
  MatDialogCloseComponent,
} from '../../fragments/mat-dialog-container/fragments/mat-dialog-content/fragments/mat-dialog-header/fragments/mat-dialog-close/mat-dialog-close.component';
import {
  MatDialogTitleComponent,
} from '../../fragments/mat-dialog-container/fragments/mat-dialog-content/fragments/mat-dialog-header/fragments/mat-dialog-title/mat-dialog-title.component';
import {
  MatDialogHeaderComponent,
} from '../../fragments/mat-dialog-container/fragments/mat-dialog-content/fragments/mat-dialog-header/mat-dialog-header.component';
import { MatDialogContentComponent } from '../../fragments/mat-dialog-container/fragments/mat-dialog-content/mat-dialog-content.component';
import {
  IMatDialogContainerComponentCloseType,
  MatDialogContainerComponent,
} from '../../fragments/mat-dialog-container/mat-dialog-container.component';

// @ts-ignore
import html from './mat-dialog-basic.component.html?raw';
// @ts-ignore
import style from './mat-dialog-basic.component.scss?inline';

/** TYPES **/

export type IMatDialogBasicComponentCloseType =
  | IMatDialogContainerComponentCloseType
  | 'close-icon'
  ;

/**
 * COMPONENT: 'mat-dialog-basic'
 */

interface IData {
  readonly $matDialogContainerClose: IObserver<IMatDialogContainerComponentCloseType>;
  readonly $onClickCloseIcon: IObserver<MouseEvent>;
}

export interface IMatDialogBasicComponentConfig {
  element: HTMLElement;
  outputs: [
    ['close', IMatDialogBasicComponentCloseType],
  ],
  data: IData;
}

export const MatDialogBasicComponent = createComponent<IMatDialogBasicComponentConfig>({
  name: 'mat-dialog-basic',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    customElements: [
      MatDialogContainerComponent,
      MatDialogContentComponent,
      MatDialogHeaderComponent,
      MatDialogTitleComponent,
      MatDialogCloseComponent,
      MatDialogBodyComponent,
      MatDialogFooterComponent,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  outputs: [
    ['close'],
  ],
  init: (node: VirtualCustomElementNode<IMatDialogBasicComponentConfig>): IData => {
    const $close = node.outputs.$set('close');

    const $matDialogContainerClose = $close;

    const $onClickCloseIcon = (): void => {
      $close('close-icon');
    };

    return {
      $matDialogContainerClose,
      $onClickCloseIcon,
    };
  },
});
