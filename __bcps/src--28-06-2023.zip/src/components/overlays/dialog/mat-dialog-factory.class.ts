import {
  createManualStylePropertyTransition,
  createNumberTransition,
  IVoidTransitionFunction,
  mapTransition,
  parallelTransitions,
} from '@lirx/animations';
import { IComponent, IVirtualCustomElementNodeConfig, querySelectorOrThrow, VirtualCustomElementNode } from '@lirx/dom';
import {
  createMatOverlayFactoryOptionsFromReversibleTransitionFactory,
} from '../shared/factory/functions/create-mat-overlay-factory-options-from-reversible-transition-factory';
import { MatOverlayFactory } from '../shared/factory/mat-overlay-factory.class';

/** CLASS **/

export interface IMatDialogFactoryOptions {
  animationDuration?: number;
}

export class MatDialogFactory<GConfig extends IVirtualCustomElementNodeConfig> extends MatOverlayFactory<GConfig> {

  constructor(
    component: IComponent<GConfig>,
    {
      animationDuration = 150,
    }: IMatDialogFactoryOptions = {},
  ) {
    super(
      component,
      createMatOverlayFactoryOptionsFromReversibleTransitionFactory({
        transitionFactory: (
          node: VirtualCustomElementNode<GConfig>,
        ): IVoidTransitionFunction => {
          return getMatDialogAnimationTransition({
            element: node.elementNode as HTMLElement,
          });
        },
        duration: animationDuration,
      }),
    );
  }
}

/** FUNCTIONS **/

/* TRANSITION */

interface IGetMatDialogAnimationTransitionOptions {
  element: HTMLElement;
}

function getMatDialogAnimationTransition(
  {
    element,
  }: IGetMatDialogAnimationTransitionOptions,
): IVoidTransitionFunction {

  const containerElement: HTMLElement = querySelectorOrThrow(element, 'mat-dialog-container');
  const contentElement: HTMLElement = querySelectorOrThrow(containerElement, 'mat-dialog-content');

  const opacityTransition = createManualStylePropertyTransition(
    containerElement,
    'opacity',
    mapTransition(createNumberTransition(0, 1), String),
  );

  const transformTransition = createManualStylePropertyTransition(
    contentElement,
    'transform',
    mapTransition(createNumberTransition(0.75, 1), _ => `scale(${_})`),
  );

  const transition = parallelTransitions([
    opacityTransition,
    transformTransition,
  ]);

  containerElement.style.willChange = 'opacity';
  contentElement.style.willChange = 'transform';

  transition(0);

  return transition;
}
