export type IMatSnackbarComponentWidth =
  | 'auto'
  | 'static'
  ;
