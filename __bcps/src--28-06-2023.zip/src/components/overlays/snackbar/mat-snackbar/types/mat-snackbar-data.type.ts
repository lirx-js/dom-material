import { IMatSnackbarComponentHorizontalPosition } from './mat-snackbar-component-horizontal-position.type';
import { IMatSnackbarComponentVerticalPosition } from './mat-snackbar-component-vertical-position.type';
import { IMatSnackbarComponentWidth } from './mat-snackbar-component-width.type';
import { IMatSnackbarOnClickAction } from './mat-snackbar-on-click-action.type';

export interface IMatSnackbarData {
  message: string;
  actionText?: string | undefined;
  horizontalPosition?: IMatSnackbarComponentHorizontalPosition | undefined;
  verticalPosition?: IMatSnackbarComponentVerticalPosition | undefined;
  width?: IMatSnackbarComponentWidth | undefined;
  onClickAction?: IMatSnackbarOnClickAction;
}
