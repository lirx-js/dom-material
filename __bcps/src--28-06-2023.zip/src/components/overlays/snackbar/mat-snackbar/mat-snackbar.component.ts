import { function$$, IObservable, IObserver, map$$ } from '@lirx/core';
import {
  compileReactiveHTMLAsComponentTemplate,
  compileStyleAsComponentStyle,
  createComponent,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { noop } from '@lirx/utils';
import { MatBasicButtonSecondaryModifier } from '../../../buttons/mat-button/built-in/basic/secondary/mat-basic-button-secondary.modifier';
import { getMatOverlayData$$ } from '../../shared/mat-overlay-input/functions/get-mat-overlay-data';
import { MAT_OVERLAY_INPUT_NAME } from '../../shared/mat-overlay-input/mat-overlay-input-name.constant';
import { IMatOverlayInput } from '../../shared/mat-overlay-input/mat-overlay-input.type';
import { IMatSnackbarComponentHorizontalPosition } from './types/mat-snackbar-component-horizontal-position.type';
import { IMatSnackbarComponentVerticalPosition } from './types/mat-snackbar-component-vertical-position.type';
import { IMatSnackbarComponentWidth } from './types/mat-snackbar-component-width.type';
import { IMatSnackbarData } from './types/mat-snackbar-data.type';
import { IMatSnackbarOnClickAction } from './types/mat-snackbar-on-click-action.type';

// @ts-ignore
import html from './mat-snackbar.component.html?raw';
// @ts-ignore
import style from './mat-snackbar.component.scss?inline';

/**
 * COMPONENT: 'mat-snackbar'
 */

interface IData {
  readonly message$: IObservable<string>;
  readonly hasAction$: IObservable<boolean>;
  readonly actionText$: IObservable<string>;
  readonly $onClickActionButton: IObservable<IObserver<MouseEvent>>;
}

export interface IMatSnackbarComponentConfig {
  element: HTMLElement;
  inputs: [
    IMatOverlayInput<IMatSnackbarComponentConfig, IMatSnackbarData>,
  ];
  data: IData;
}

export type IMatSnackbarVirtualCustomElementNode = VirtualCustomElementNode<IMatSnackbarComponentConfig>;

export const MatSnackbarComponent = createComponent<IMatSnackbarComponentConfig>({
  name: 'mat-snackbar',
  template: compileReactiveHTMLAsComponentTemplate({
    html,
    modifiers: [
      MatBasicButtonSecondaryModifier,
    ],
  }),
  styles: [compileStyleAsComponentStyle(style)],
  inputs: [
    [MAT_OVERLAY_INPUT_NAME],
  ],
  init: (node: VirtualCustomElementNode<IMatSnackbarComponentConfig>): IData => {
    const data$ = getMatOverlayData$$(node);

    // INPUTS
    const message$ = map$$(data$, data => data.message);
    const actionText$ = map$$(data$, data => data.actionText);
    const horizontalPosition$ = map$$(data$, data => data.horizontalPosition);
    const verticalPosition$ = map$$(data$, data => data.verticalPosition);
    const width$ = map$$(data$, data => data.width);

    // OUTPUTS
    const $onClickAction = map$$(data$, data => data.onClickAction);

    // ACTION
    const actionTextNormalized$ = map$$(actionText$, (value: string | undefined): string => {
      return (value === void 0)
        ? ''
        : value;
    });

    const hasAction$ = map$$(actionTextNormalized$, (actionText: string | undefined): boolean => {
      return (actionText !== '');
    });

    const $onClickActionButton = map$$($onClickAction, (onClickAction: IMatSnackbarOnClickAction | undefined): IObserver<MouseEvent> => {
      return onClickAction ?? noop;
    });

    // POSITIONS & WIDTH
    const horizontalPositionNormalized$ = map$$(horizontalPosition$, (value: IMatSnackbarComponentHorizontalPosition | undefined): IMatSnackbarComponentHorizontalPosition => {
      return (value === void 0)
        ? MAT_SNACKBAR_COMPONENT_DEFAULT_HORIZONTAL_POSITION
        : value;
    });

    const verticalPositionNormalized$ = map$$(verticalPosition$, (value: IMatSnackbarComponentVerticalPosition | undefined): IMatSnackbarComponentVerticalPosition => {
      return (value === void 0)
        ? MAT_SNACKBAR_COMPONENT_DEFAULT_VERTICAL_POSITION
        : value;
    });

    const widthNormalized$ = map$$(width$, (value: IMatSnackbarComponentWidth | undefined): IMatSnackbarComponentWidth => {
      return (value === void 0)
        ? MAT_SNACKBAR_COMPONENT_DEFAULT_WIDTH
        : value;
    });

    const classList$ = function$$(
      [horizontalPositionNormalized$, verticalPositionNormalized$, widthNormalized$],
      (horizontalPosition, verticalPosition, width) => {
        return new Set([
          `mat--position-${horizontalPosition}`,
          `mat--position-${verticalPosition}`,
          `mat--width-${width}`,
        ]);
      },
    );
    node.setReactiveClassNamesList(classList$);

    return {
      message$,
      hasAction$,
      actionText$: actionTextNormalized$,
      $onClickActionButton,
    };
  },
});

/** CONSTANTS **/

export const MAT_SNACKBAR_COMPONENT_DEFAULT_HORIZONTAL_POSITION: IMatSnackbarComponentHorizontalPosition = 'right';
export const MAT_SNACKBAR_COMPONENT_DEFAULT_VERTICAL_POSITION: IMatSnackbarComponentVerticalPosition = 'bottom';
export const MAT_SNACKBAR_COMPONENT_DEFAULT_WIDTH: IMatSnackbarComponentWidth = 'static';
