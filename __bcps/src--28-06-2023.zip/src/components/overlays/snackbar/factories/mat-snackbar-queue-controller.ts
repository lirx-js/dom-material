import { IMatSnackbarComponentConfig } from '../mat-snackbar/mat-snackbar.component';
import { MatSnackbarController } from './mat-snackbar-controller';
import { MatSnackbarQueueFactory } from './mat-snackbar-queue-factory';

export const MatSnackbarQueueController = new MatSnackbarQueueFactory<IMatSnackbarComponentConfig>(MatSnackbarController);
