import {
  createManualStylePropertyTransition,
  createNumberTransition,
  ITransitionFunction,
  IVoidTransitionFunction,
  mapTransition,
  parallelTransitions,
} from '@lirx/animations';
import { toPromise } from '@lirx/core';
import { IComponent, IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { isObject } from '@lirx/utils';
import {
  createMatOverlayFactoryOptionsFromReversibleTransitionFactory
} from '../../shared/factory/functions/create-mat-overlay-factory-options-from-reversible-transition-factory';
import { MatOverlayFactory } from '../../shared/factory/mat-overlay-factory.class';
import { getMatOverlayData$$ } from '../../shared/mat-overlay-input/functions/get-mat-overlay-data';
import {
  MAT_SNACKBAR_COMPONENT_DEFAULT_HORIZONTAL_POSITION,
  MAT_SNACKBAR_COMPONENT_DEFAULT_VERTICAL_POSITION,
} from '../mat-snackbar/mat-snackbar.component';
import { IMatSnackbarComponentHorizontalPosition } from '../mat-snackbar/types/mat-snackbar-component-horizontal-position.type';
import { IMatSnackbarComponentVerticalPosition } from '../mat-snackbar/types/mat-snackbar-component-vertical-position.type';

/** CLASS **/

export interface IMatSnackbarFactoryOptions {
  animationDuration?: number;
}

export class MatSnackbarFactory<GConfig extends IVirtualCustomElementNodeConfig> extends MatOverlayFactory<GConfig> {
  constructor(
    component: IComponent<GConfig>,
    {
      animationDuration = 150,
    }: IMatSnackbarFactoryOptions = {},
  ) {
    super(
      component,
      createMatOverlayFactoryOptionsFromReversibleTransitionFactory({
        transitionFactory: (
          node: VirtualCustomElementNode<GConfig>,
          signal: AbortSignal,
        ): Promise<IVoidTransitionFunction> => {
          return toPromise(
            getMatOverlayData$$<GConfig>(node),
            { signal },
          )
            .then((data: unknown): IVoidTransitionFunction => {
              let horizontalPosition: IMatSnackbarComponentHorizontalPosition | undefined;
              let verticalPosition: IMatSnackbarComponentVerticalPosition | undefined;

              if (isObject(data)) {
                if ('horizontalPosition' in data) {
                  horizontalPosition = data.horizontalPosition as any;
                }
                if ('verticalPosition' in data) {
                  verticalPosition = data.verticalPosition as any;
                }
              }

              return getMatSnackbarAnimationTransition({
                element: node.elementNode as HTMLElement,
                horizontalPosition,
                verticalPosition,
              });
            });
        },
        duration: animationDuration,
      }),
    );
  }
}

/** FUNCTIONS **/

/* TRANSITION */

interface IGetMatSnackbarAnimationTransitionOptions extends IGetMatSnackbarAnimationTransformTransitionOptions {
  element: HTMLElement;
}

function getMatSnackbarAnimationTransition(
  {
    element,
    ...options
  }: IGetMatSnackbarAnimationTransitionOptions,
): IVoidTransitionFunction {

  const opacityTransition = createManualStylePropertyTransition(
    element,
    'opacity',
    mapTransition(createNumberTransition(0, 1), String),
  );

  const transformTransition = createManualStylePropertyTransition(
    element,
    'transform',
    getMatSnackbarAnimationTransformTransition(options),
  );

  const transition = parallelTransitions([
    opacityTransition,
    transformTransition,
  ]);

  element.style.willChange = 'transform, opacity';

  transition(0);

  return transition;
}

interface IGetMatSnackbarAnimationTransformTransitionOptions {
  horizontalPosition?: IMatSnackbarComponentHorizontalPosition | undefined;
  verticalPosition?: IMatSnackbarComponentVerticalPosition | undefined;
}

function getMatSnackbarAnimationTransformTransition(
  {
    horizontalPosition = MAT_SNACKBAR_COMPONENT_DEFAULT_HORIZONTAL_POSITION,
    verticalPosition = MAT_SNACKBAR_COMPONENT_DEFAULT_VERTICAL_POSITION,
  }: IGetMatSnackbarAnimationTransformTransitionOptions,
): ITransitionFunction<string> {
  if (horizontalPosition === 'left') {
    return mapTransition(createNumberTransition(-120, 0), _ => `translateX(${_}%)`);
  } else if (horizontalPosition === 'right') {
    return mapTransition(createNumberTransition(120, 0), _ => `translateX(${_}%)`);
  } else {
    if (verticalPosition === 'bottom') {
      return mapTransition(createNumberTransition(120, 0), _ => `translateY(${_}%)`);
    } else {
      return mapTransition(createNumberTransition(-120, 0), _ => `translateY(${_}%)`);
    }
  }
}


