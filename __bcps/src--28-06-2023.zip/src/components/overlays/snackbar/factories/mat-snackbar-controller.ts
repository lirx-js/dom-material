import { IMatSnackbarComponentConfig, MatSnackbarComponent } from '../mat-snackbar/mat-snackbar.component';
import { MatSnackbarFactory } from './mat-snackbar-factory.class';

export const MatSnackbarController = new MatSnackbarFactory<IMatSnackbarComponentConfig>(MatSnackbarComponent);


