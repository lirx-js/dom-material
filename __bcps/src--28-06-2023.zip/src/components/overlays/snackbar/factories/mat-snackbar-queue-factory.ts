import { empty, single } from '@lirx/core';
import { IVirtualCustomElementNodeConfig } from '@lirx/dom';
import {
  IMatOverlayFactoryOpenData,
  IMatOverlayFactoryOpenOptions, IMatOverlayFactoryOpenStaticData,
} from '../../shared/factory/types/mat-overlay-factory-open-options.type';
import {
  InferMatOverlayFromVirtualCustomElementNodeConfig
} from '../../shared/instance/types/from-virtual-custom-element-node-config/infer-mat-overlay-from-virtual-custom-element-node-config.type';
import { IGenericMatOverlay } from '../../shared/instance/types/generic-mat-overlay.type';
import { IMatOverlayState } from '../../shared/instance/types/mat-overlay-state.type';
import { MatSnackbarFactory } from './mat-snackbar-factory.class';

/** TYPES **/

/* OPEN */

export interface IMatSnackbarQueueFactoryOpenOptions extends IMatOverlayFactoryOpenOptions {
  displayDuration?: number;
  queueStrategy?: 'await-previous-closed' | 'force-previous-close';
}

/** CLASS **/

export class MatSnackbarQueueFactory<GConfig extends IVirtualCustomElementNodeConfig> {
  readonly #matSnackbarFactory: MatSnackbarFactory<GConfig>;
  #openPromise: Promise<InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig>> | undefined;

  constructor(
    matSnackbarFactory: MatSnackbarFactory<GConfig>,
  ) {
    this.#matSnackbarFactory = matSnackbarFactory;
  }

  open(
    data$: IMatOverlayFactoryOpenData<GConfig>,
    {
      displayDuration,
      queueStrategy = 'await-previous-closed',
      ...options
    }: IMatSnackbarQueueFactoryOpenOptions = {},
  ): Promise<InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig>> {
    const promise: Promise<any> = (this.#openPromise === void 0)
      ? Promise.resolve()
      : this.#openPromise
        .then((overlay: IGenericMatOverlay): Promise<any> => {
          switch (queueStrategy) {
            case 'await-previous-closed':
              return overlay.untilState('closed');
            case 'force-previous-close':
              return overlay.close();
          }
        });

    return this.#openPromise = promise
      .then((): Promise<InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig>> => {
        const snackbar: IGenericMatOverlay = this.#matSnackbarFactory.open(data$, options);

        return snackbar.untilState('opened')
          .then(() => {
            if (
              (displayDuration !== void 0)
              && (displayDuration > 0)
            ) {
              let timer: any;

              const end = (): void => {
                if (timer !== void 0) {
                  clearTimeout(timer);
                  timer = void 0;
                }
                unsubscribe();
              };

              timer = setTimeout((): void => {
                end();
                snackbar.close();
              }, displayDuration);

              const unsubscribe = snackbar.state$((state: IMatOverlayState): void => {
                if (
                  (state === 'closing')
                  || (state === 'closed')
                ) {
                  end();
                }
              });
            }

            return snackbar;
          });
      });
  }

  openStatic(
    data: IMatOverlayFactoryOpenStaticData<GConfig>,
    options?: IMatSnackbarQueueFactoryOpenOptions,
  ): Promise<InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig>> {
    return this.open(
      (
        (data === void 0)
          ? empty()
          : single(data)
      ) as any,
      options,
    );
  }
}
