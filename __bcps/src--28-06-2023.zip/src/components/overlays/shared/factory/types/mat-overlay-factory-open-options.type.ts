import { IObservable } from '@lirx/core';
import { IVirtualCustomElementNodeConfig, IVirtualCustomElementNodeConfigInputs, IVirtualCustomElementNodeSlotsMap } from '@lirx/dom';
import {
  InferMatOverlayDataFromVirtualCustomElementNodeConfig,
} from '../../instance/types/from-virtual-custom-element-node-config/infer-mat-overlay-data-from-virtual-custom-element-node-config.type';

export interface IMatOverlayFactoryOpenOptions {
  slots?: IVirtualCustomElementNodeSlotsMap;
}

export type IMatOverlayFactoryOpenDataFromData<GData> =
  [GData] extends [never]
    ? (undefined | void | IObservable<never>)
    : IObservable<GData>;

export type IMatOverlayFactoryOpenData<GConfig extends IVirtualCustomElementNodeConfig> =
  IMatOverlayFactoryOpenDataFromData<InferMatOverlayDataFromVirtualCustomElementNodeConfig<GConfig>>;

export type IMatOverlayFactoryOpenStaticDataFromData<GData> =
  [GData] extends [never]
    ? (undefined | void)
    : GData;

export type IMatOverlayFactoryOpenStaticData<GConfig extends IVirtualCustomElementNodeConfig> =
  IMatOverlayFactoryOpenStaticDataFromData<InferMatOverlayDataFromVirtualCustomElementNodeConfig<GConfig>>;


/*-----------------*/

// export type InferVirtualCustomElementNodeOptionsInputsInterface<GConfig extends IVirtualCustomElementNodeConfig> =
//   PartialInterfaceIfTupleIsEmpty<InferVirtualCustomElementNodeConfigInputs<GConfig>, {
//     inputs: InferVirtualCustomElementNodeOptionsInputs<GConfig>
//   }>
//   ;

// export type InferVirtualCustomElementNodeConfigInputs<GConfig extends IVirtualCustomElementNodeConfig> =
//   GConfig['inputs'] extends IVirtualCustomElementNodeConfigInputs
//     ? GConfig['inputs']
//     : [];
//

export type InferKeysOfVirtualCustomElementNodeConfigInputs<GInputs extends IVirtualCustomElementNodeConfigInputs> = {
  [Key in keyof GInputs]: GInputs[Key][0];
};

export type InferValuesOfVirtualCustomElementNodeConfigInputs<GInputs extends IVirtualCustomElementNodeConfigInputs> = {
  [Key in keyof GInputs]: GInputs[Key][1];
};

export type PInferVirtualCustomElementNodeOptionsInputsFromInputs<GInputs extends IVirtualCustomElementNodeConfigInputs> = {
  [Key in keyof InferKeysOfVirtualCustomElementNodeConfigInputs<GInputs>]: GInputs[Key][0];
};

// export type InferVirtualCustomElementNodeOptionsInputs<GConfig extends IVirtualCustomElementNodeConfig> =
//   InferVirtualCustomElementNodeOptionsInputsFromInputs<InferVirtualCustomElementNodeConfigInputs<GConfig>>;


type Inputs = [
  ['a', string],
  ['b', number],
];

type A = PInferVirtualCustomElementNodeOptionsInputsFromInputs<Inputs>;

const a: PInferVirtualCustomElementNodeOptionsInputsFromInputs<Inputs> = null as any;
