import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { IMatOverlayOptions } from '../../instance/types/mat-overlay-options.type';
import {
  InferMatOverlayDataFromVirtualCustomElementNodeConfig
} from '../../instance/types/from-virtual-custom-element-node-config/infer-mat-overlay-data-from-virtual-custom-element-node-config.type';

export interface IMatOverlayFactoryOptions<GConfig extends IVirtualCustomElementNodeConfig> extends Omit<IMatOverlayOptions<VirtualCustomElementNode<GConfig>, InferMatOverlayDataFromVirtualCustomElementNodeConfig<GConfig>>, 'node' | 'data$'> {
}
