import { IVoidTransitionFunction } from '@lirx/animations';
import { IVirtualCustomElementNodeConfig } from '@lirx/dom';
import { IMatOverlayFactoryOptions } from '../types/mat-overlay-factory-options.type';
import {
  createMatOverlayFactoryOptionsFromReversibleTransitionFactory,
  ICreateMatOverlayFactoryOptionsFromReversibleTransitionFactoryOptions,
} from './create-mat-overlay-factory-options-from-reversible-transition-factory';

export interface ICreateMatOverlayFactoryOptionsFromReversibleTransitionOptions extends Omit<ICreateMatOverlayFactoryOptionsFromReversibleTransitionFactoryOptions<any>, 'transitionFactory'> {
  transition: IVoidTransitionFunction;
}

export function createMatOverlayFactoryOptionsFromReversibleTransition<GConfig extends IVirtualCustomElementNodeConfig>(
  {
    transition,
    ...options
  }: ICreateMatOverlayFactoryOptionsFromReversibleTransitionOptions,
): IMatOverlayFactoryOptions<GConfig> {
  return createMatOverlayFactoryOptionsFromReversibleTransitionFactory({
    ...options,
    transitionFactory: () => transition,
  });
}

