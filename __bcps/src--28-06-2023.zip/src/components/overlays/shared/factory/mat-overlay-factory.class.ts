import { empty, single } from '@lirx/core';
import {
  getVirtualCustomElementNodeInputsMap,
  IComponent,
  IVirtualCustomElementNodeConfig,
  IVirtualCustomElementNodeInputsMap,
  VirtualCustomElementNode,
} from '@lirx/dom';
import { MatOverlay } from '../instance/mat-overlay.class';
import {
  InferMatOverlayDataFromVirtualCustomElementNodeConfig,
} from '../instance/types/from-virtual-custom-element-node-config/infer-mat-overlay-data-from-virtual-custom-element-node-config.type';
import {
  InferMatOverlayFromVirtualCustomElementNodeConfig,
} from '../instance/types/from-virtual-custom-element-node-config/infer-mat-overlay-from-virtual-custom-element-node-config.type';
import { MAT_OVERLAY_INPUT_NAME } from '../mat-overlay-input/mat-overlay-input-name.constant';
import {
  IMatOverlayFactoryOpenData,
  IMatOverlayFactoryOpenOptions,
  IMatOverlayFactoryOpenStaticData,
} from './types/mat-overlay-factory-open-options.type';
import { IMatOverlayFactoryOptions } from './types/mat-overlay-factory-options.type';

/**
 * This class is used to generate an overlay from a component.
 */
export class MatOverlayFactory<GConfig extends IVirtualCustomElementNodeConfig> {
  readonly #component: IComponent<GConfig>;
  readonly #options: IMatOverlayFactoryOptions<GConfig>;

  constructor(
    component: IComponent<GConfig>,
    options: IMatOverlayFactoryOptions<GConfig> = {},
  ) {
    this.#component = component;
    this.#options = options;
  }

  get component(): IComponent<GConfig> {
    return this.#component;
  }


  /**
   * Creates the "overlay" from the component. You may provide some data.
   * It returns a MatOverlay, which animates the overlay, and provides a method to close it.
   */
  open(
    data$: IMatOverlayFactoryOpenData<GConfig>,
    {
      slots,
    }: IMatOverlayFactoryOpenOptions = {},
  ): InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig> {
    const instance = new MatOverlay<VirtualCustomElementNode<GConfig>, InferMatOverlayDataFromVirtualCustomElementNodeConfig<GConfig>>({
      ...this.#options,
      node: this.#component.create(slots),
      data$: data$ ?? empty() as any,
    });

    const map: IVirtualCustomElementNodeInputsMap = getVirtualCustomElementNodeInputsMap(instance.node);

    if (map.has(MAT_OVERLAY_INPUT_NAME)) {
      map.get(MAT_OVERLAY_INPUT_NAME)![0](instance);
    }

    return instance;
  }

  openStatic(
    data: IMatOverlayFactoryOpenStaticData<GConfig>,
    options?: IMatOverlayFactoryOpenOptions,
  ): InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig> {
    return this.open(
      (
        (data === void 0)
          ? empty()
          : single(data)
      ) as any,
      options,
    );
  }
}
