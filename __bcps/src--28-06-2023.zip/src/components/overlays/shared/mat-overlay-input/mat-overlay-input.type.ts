import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import { MatOverlay } from '../instance/mat-overlay.class';
import { IMatOverlayInputName } from './mat-overlay-input-name.type';

export type IMatOverlayInput<GConfig extends IVirtualCustomElementNodeConfig, GData> = [
  IMatOverlayInputName,
  MatOverlay<VirtualCustomElementNode<GConfig>, GData>,
];
