import { IObservable, switchMap$$ } from '@lirx/core';
import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import {
  InferMatOverlayDataFromVirtualCustomElementNodeConfig,
} from '../../instance/types/from-virtual-custom-element-node-config/infer-mat-overlay-data-from-virtual-custom-element-node-config.type';
import { getMatOverlayInput$$ } from './get-mat-overlay-input';

export function getMatOverlayData$$<GConfig extends IVirtualCustomElementNodeConfig>(
  node: VirtualCustomElementNode<GConfig>,
): IObservable<InferMatOverlayDataFromVirtualCustomElementNodeConfig<GConfig>> {
  return switchMap$$(getMatOverlayInput$$(node), _ => _.data$);
}
