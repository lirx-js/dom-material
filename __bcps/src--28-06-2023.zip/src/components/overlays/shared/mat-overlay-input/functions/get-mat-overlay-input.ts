import { IObservable } from '@lirx/core';
import { IVirtualCustomElementNodeConfig, VirtualCustomElementNode } from '@lirx/dom';
import {
  InferMatOverlayFromVirtualCustomElementNodeConfig,
} from '../../instance/types/from-virtual-custom-element-node-config/infer-mat-overlay-from-virtual-custom-element-node-config.type';
import { MAT_OVERLAY_INPUT_NAME } from '../mat-overlay-input-name.constant';

export function getMatOverlayInput$$<GConfig extends IVirtualCustomElementNodeConfig>(
  node: VirtualCustomElementNode<GConfig>,
): IObservable<InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig>> {
  return node.inputs.get$(MAT_OVERLAY_INPUT_NAME);
}
