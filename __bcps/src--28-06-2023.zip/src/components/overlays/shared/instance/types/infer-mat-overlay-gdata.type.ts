import { MatOverlay } from '../mat-overlay.class';
import { IGenericMatOverlay } from './generic-mat-overlay.type';

export type InferMatOverlayGData<GMatOverlay extends IGenericMatOverlay> =
  GMatOverlay extends MatOverlay<any, infer GData>
    ? GData
    : never;
