import { InferVirtualCustomElementNodeInputValue, IVirtualCustomElementNodeConfig } from '@lirx/dom';
import { IMatOverlayInputName } from '../../../mat-overlay-input/mat-overlay-input-name.type';

export type InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig extends IVirtualCustomElementNodeConfig> = InferVirtualCustomElementNodeInputValue<GConfig, IMatOverlayInputName>;
