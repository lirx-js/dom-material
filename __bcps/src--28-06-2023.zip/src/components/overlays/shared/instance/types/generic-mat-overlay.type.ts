import { MatOverlay } from '../mat-overlay.class';

export type IGenericMatOverlay = MatOverlay<any, any>;
