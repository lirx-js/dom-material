import { IObservable } from '@lirx/core';
import { VirtualNode } from '@lirx/dom';
import { IMatOverlayCloseFunction } from './mat-overlay-close-function.type';
import { IMatOverlayOpenFunction } from './mat-overlay-open-function.type';

export interface IMatOverlayOptions<GNode extends VirtualNode, GData> {
  node: GNode;
  data$: IObservable<GData>;
  open?: IMatOverlayOpenFunction<GNode>;
  close?: IMatOverlayCloseFunction<GNode>;
}
