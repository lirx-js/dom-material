import { IVirtualCustomElementNodeConfig } from '@lirx/dom';
import {
  InferMatOverlayFromVirtualCustomElementNodeConfig,
} from './infer-mat-overlay-from-virtual-custom-element-node-config.type';
import { InferMatOverlayGData } from '../infer-mat-overlay-gdata.type';

export type InferMatOverlayDataFromVirtualCustomElementNodeConfig<GConfig extends IVirtualCustomElementNodeConfig> =
  InferMatOverlayGData<InferMatOverlayFromVirtualCustomElementNodeConfig<GConfig>>;
