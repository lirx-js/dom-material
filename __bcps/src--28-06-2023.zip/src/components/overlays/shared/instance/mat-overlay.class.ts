import {
  createMulticastReplayLastSource,
  filter$$,
  IMulticastReplayLastSource,
  IObservable,
  IObservableToPromiseOptions,
  toPromise,
} from '@lirx/core';
import { VirtualNode } from '@lirx/dom';
import { MatOverlayContainer } from '../container/mat-overlay-container.class';
import { IMatOverlayCloseFunction } from './types/mat-overlay-close-function.type';
import { IMatOverlayOptions } from './types/mat-overlay-options.type';
import { IMatOverlayState } from './types/mat-overlay-state.type';

const DEFAULT_MAT_OVERLAY_INSTANCE_OPEN_FUNCTION = () => Promise.resolve();
const DEFAULT_MAT_OVERLAY_INSTANCE_CLOSE_FUNCTION = () => Promise.resolve();

/**
 * This class controls the state of an overlay.
 */
export class MatOverlay<GNode extends VirtualNode, GData> {
  readonly #node: GNode;
  readonly #data$: IObservable<GData>;
  readonly #$state$: IMulticastReplayLastSource<IMatOverlayState>;
  readonly #controller: AbortController;
  readonly #close: IMatOverlayCloseFunction<GNode>;
  #stateUpdatingPromise: Promise<void>;

  constructor(
    {
      node,
      data$,
      open = DEFAULT_MAT_OVERLAY_INSTANCE_OPEN_FUNCTION,
      close = DEFAULT_MAT_OVERLAY_INSTANCE_CLOSE_FUNCTION,
    }: IMatOverlayOptions<GNode, GData>,
  ) {
    this.#node = node;
    this.#data$ = data$;
    this.#$state$ = createMulticastReplayLastSource<IMatOverlayState>('opening');
    this.#controller = new AbortController();
    this.#close = close;

    node.attach(MatOverlayContainer.node);

    this.#stateUpdatingPromise = open(node, this.#controller.signal)
      .then(
        (): void => {
          this.#$state$.emit('opened');
        },
        (error: unknown): void => {
          if (!this.#controller.signal.aborted) {
            throw error;
          }
        },
      );
  }

  get node(): GNode {
    return this.#node;
  }

  get data$(): IObservable<GData> {
    return this.#data$;
  }

  get state(): IMatOverlayState {
    return this.#$state$.getValue();
  }

  get state$(): IObservable<IMatOverlayState> {
    return this.#$state$.subscribe;
  }

  untilState$<GState extends IMatOverlayState>(
    state: GState,
  ): IObservable<GState> {
    return filter$$<IMatOverlayState, GState>(this.#$state$.subscribe, (_state: IMatOverlayState): _state is GState => (_state === state));
  }

  untilState<GState extends IMatOverlayState>(
    state: GState,
    options?: IObservableToPromiseOptions,
  ): Promise<GState> {
    return toPromise(this.untilState$<GState>(state), options);
  }

  close(): Promise<void> {
    if (
      (this.state === 'opening')
      || (this.state === 'opened')
    ) {
      this.#controller.abort();
      this.#$state$.emit('closing');
      this.#stateUpdatingPromise = this.#stateUpdatingPromise
        .then((): Promise<void> => {
          return this.#close(this.#node)
        })
        .then((): void => {
          this.#node.detach();
          this.#$state$.emit('closed');
        });
    }
    return this.#stateUpdatingPromise;
  }
}

